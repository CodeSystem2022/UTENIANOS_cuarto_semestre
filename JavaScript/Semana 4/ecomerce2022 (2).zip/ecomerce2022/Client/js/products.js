const productos = [ 
    { 
       id: 1,
       productName: "banana",
       price: 480,
       quanty: 1,
       img: "/Client/media/banana.png",
    },
    { 
         id: 2,
         productName: "leche",
         price: 950,
         quanty: 1,
         img: "/Client/media/leche.png",
    },
      { 
         id: 3,
         productName:"pollo",
         price: 750,
         quanty: 1,
         img: "/Client/media/pollo.png",
      },
      { 
         id: 4,
         productName: "mayonesa",
         price: 950,
         quanty: 1,
         img: "/Client/media/mayonesa.png",
      },
      { 
         id: 5,
         productName: "enlatados",
         price: 700,
         quanty: 1,
         img: "/Client/media/enlatados.png",
      },
  ]
   